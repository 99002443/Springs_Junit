package com.training.example;

public class NegValueException extends RuntimeException{

	public NegValueException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NegValueException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	
	

}
