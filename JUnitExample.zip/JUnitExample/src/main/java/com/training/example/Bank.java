package com.training.example;

public class Bank {

	double balance;

	public Bank(double balance) {
		super();
		this.balance = balance;
	}

	public double withdraw(double amount) throws ExceedingException{
		if(amount>4000) {
			throw new ExceedingException("amount beyond limit");
		}
		if(amount<=0) {
			throw new NegValueException("amount less than zero ");
		}
		balance= balance-amount;
		return balance;
	}
	public double deposit(double amount) throws ExceedingException{
		if(amount>=15000) {
			throw new ExceedingException("amount beyond the limit");
		}
		if(amount<=0) {
			throw new NegValueException("amount less than zero");
		}
		balance = balance+amount;
		return balance;
	}
	

}
