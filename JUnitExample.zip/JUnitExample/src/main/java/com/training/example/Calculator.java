package com.training.example;

public class Calculator {

	public int sum(int x, int y) {
		return x+y;
	}
	public int sub(int x, int y) {
		return x-y;
	}
	public int mul(int x, int y) {
		return x*y;
	}
	public int div(int x, int y)
	{
		return x/y;
	}
	public double avg(int x, int y, int z) {
		if(x>100 || y>100|| z>100) {
		throw new ExceedingException("More than the limit");
		}
		return (x+y+z)/3;
	}

}
